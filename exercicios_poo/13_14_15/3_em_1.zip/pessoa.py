class Pessoa:

    def __init__(self, pessoa):
        self.pessoa = pessoa